# -*- coding: utf-8 -*-
"""
Created on Sun Dec 11 22:51:43 2022

@author: Najmun Nahar,
         Ebtisam Abdulkaliq,
         Shafiya Heena,
         Gagandeep Kaur,
         Anurag Mandapati
"""

from time import asctime
from random import randint
import group_4_data_generator as datagen


class util:
    
    def __init__(self):
        # On instantiation, instantiate a generator instance, then have the start ID and temperature reading from the pattern generator
        self.gen = datagen.generator()
        self.start_id = 100
        
    def create_data(self):
        # When data is requested to be created, increase the counter and gets a temperature datapoint, package up all the data and return the dictionary
        self.start_id += 1
        # Transmit “wild data” something that is completely off the chart. Again your subscriber should be able to handle this.
        self.simulate_wild_data = randint(1,42)
        if self.simulate_wild_data == 42:
            self.iot_data = { 
                'id': self.start_id, 
                'time': asctime(), 
                'temperature': 'NaN' }
        else:
            self.iot_data = { 
                'id': self.start_id, 
                'time': asctime(), 
                'temperature': self.gen.data }
        return self.iot_data

    def print_data(self, process_message):
        print(f'\n{process_message.topic} \n{process_message.payload.decode("utf-8")}')

#######
# Test Harness
#####

utility_test = util()
for x in range(11):
    print(utility_test.create_data())

