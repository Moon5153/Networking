# -*- coding: utf-8 -*-
"""
Created on Sun Dec 11 22:51:43 2022

@author: Najmun Nahar,
         Ebtisam Abdulkaliq,
         Shafiya Heena,
         Gagandeep Kaur,
         Anurag Mandapati
"""
from group_4_data_util import util
import paho.mqtt.client as mqtt
from time import sleep
from json import dumps
from random import randint
from tkinter import *
from tkinter import ttk, messagebox


class publisher(Tk):

    def __init__(self, broker_address='Localhost', broker_port=1883, topic='Group4 Project', delay=0.75):


        self.generation = util()
        self.client = mqtt.Client()
        
        # set the broker info, delay timer, and topic for this publisher object
        self.broker_address = broker_address
        self.broker_port = broker_port
        self.broker_topic = topic
        self.broker_delay = delay

        # Check to see if this app is running, and this check makes sure there isn't a conflict with TkInter's thread
        self.is_running = False

        # Initialize the broker window
        self.__initUI()

    def __initUI(self):

        # Init TkInter
        super().__init__()

        # Set window properties
        self.title('Publisher')
        self.geometry('600x250')
        tk_style = ttk.Style()
        tk_style.theme_use('clam')
        self.app_font = 'Sans'

        #publish continuously
        self.publishinfinite_button = Button(self)
        self.publishinfinite_button.configure(command=self.__button_press_publishinfinite, font=(self.app_font,'12','bold'), text='Publish Continuously', foreground='white', background="#5fdf63", width=20)
        self.publishinfinite_button.place(x=349,y=59)

        # PublishOnce button 
        self.publishonce_button = Button(self)
        self.publishonce_button.configure(command=self.__button_press_publishonce, font=(self.app_font,'12','bold'), text='Publish One Packet', foreground='green', width=20)
        self.publishonce_button.place(x=349,y=109)

        # Exit button 
        self.exit_button = Button(self)
        self.exit_button.configure(command=self.destroy, font=(self.app_font,'9','bold'), text='Exit', foreground='white',background='#e54439', width=19,height=2)
        self.exit_button.place(x=17,y=179)

        # Update broker button 
        self.broker_update_button = Button(self)
        self.broker_update_button.configure(command=lambda: self.__brokerupdate(), font=(self.app_font,'9','bold'), text='Update Broker', foreground='white', background='#4285f4', width=19,height=2)
        self.broker_update_button.place(x=169,y=179)

        # Broker Address Label
        self.broker_address_label = Label(self)
        self.broker_address_label.configure(font=(self.app_font,'9','bold'), text='Broker Address:', width=15, foreground='black', anchor='e')
        self.broker_address_label.place(x=17,y=49)

        # Broker Address Textbox
        self.broker_address_txt = Text(self, height=2)
        self.broker_address_txt.configure(font=(self.app_font,'9','bold'), width=25, foreground='black')
        self.broker_address_txt.place(x=135,y=49)
        self.broker_address_txt.insert(END,self.broker_address)

        # Broker Port Label
        self.broker_port_label = Label(self)
        self.broker_port_label.configure(font=(self.app_font,'9','bold'), text='Broker Port (1883):', width=15, foreground='black', anchor='e')
        self.broker_port_label.place(x=17,y=89)

        # Broker Port Textbox
        self.broker_port_txt = Text(self, height=2)
        self.broker_port_txt.configure(font=(self.app_font,'9','bold'), width=25, foreground='black')
        self.broker_port_txt.place(x=135,y=89)
        self.broker_port_txt.insert(END,self.broker_port)
        
        # Broker Topic Label
        self.broker_topic_label = Label(self)
        self.broker_topic_label.configure(font=(self.app_font,'9','bold'), text='Broker Topic:', width=15, foreground='black', anchor='e')
        self.broker_topic_label.place(x=17,y=129)

        # Broker Topic Textbox
        self.broker_topic_txt = Text(self, height=2)
        self.broker_topic_txt.configure(font=(self.app_font,'9','bold'), width=25, foreground='black')
        self.broker_topic_txt.place(x=135,y=129)
        self.broker_topic_txt.insert(END,self.broker_topic)

        # Data Broker Information Area
        self.data_broker_info = Label(self)
        self.data_broker_info.configure(font=(self.app_font,'11','bold'), text=' ', foreground='black')
        self.data_broker_info.place(x=17,y=19)
        self.data_broker_info['text'] = f'Broker: {self.broker_address} Port: {self.broker_port} - Topic: {self.broker_topic}'

        # Data Packet Information Area
        self.data_packet_info = Label(self)
        self.data_packet_info.configure(font=(self.app_font,'9','bold'), text=' ', foreground='black')
        self.data_packet_info.place(x=329,y=149)
    
    def __threader(self):
        if self.is_running == True:
            self.__button_press_publishonce()
        self.after(randint(1100,1700), self.__threader)
    
    def __button_press_publishinfinite(self):

        # If it is not running, start it up
        if self.is_running == False:
            self.is_running = True
            self.publishinfinite_button['text'] = 'Stop Publishing'
            self.publishonce_button['state'] = 'disabled'
            self.broker_update_button['state'] = 'disabled'
            self.exit_button['state'] = 'disabled'
            self.broker_address_txt['state'] = 'disabled'
            self.broker_port_txt['state'] = 'disabled'
            self.broker_topic_txt['state'] = 'disabled'
            self.__threader()
        else:
            self.is_running = False
            self.publishinfinite_button['text'] = 'Publish Continuously'
            self.broker_update_button['state'] = 'normal'
            self.publishonce_button['state'] = 'normal'
            self.exit_button['state'] = 'normal'
            self.broker_address_txt['state'] = 'normal'
            self.broker_port_txt['state'] = 'normal'
            self.broker_topic_txt['state'] = 'normal'

    def __button_press_publishonce(self):

        # Announce the publisher has started
        print(f'\nPublishing data to broker at {self.broker_address} on port {self.broker_port}')

        self.simulate_not_perfect_transmission = randint(1,100)
        if self.simulate_not_perfect_transmission == 100:
            # Simulate missing a packet transmission
            self.data_packet_info['text'] = f'Missed Publishing Payload Data: {self.data_payload}'
            print(f'Missed transmission of data packet: {self.data_payload}')
        else:
            # Send transmission; Get datapoint from Util class
            self.data_payload = dumps(obj=self.generation.create_data(), indent=2)
            # Start the __brokerconnect method
            self.data_packet_info['text'] = f'Publishing Payload Data: {self.data_payload}'
            self.__brokerconnect()

    def __brokerconnect(self):

        try:
            self.client.connect(host=self.broker_address, port=self.broker_port)
            self.client.publish(topic=self.broker_topic, payload=self.data_payload)
        except:
            messagebox.showwarning('Broker Publishing Problem', 'Could not publish data to broker, please verify broker data and try again.') # Different types of message boxes - REF: https://docs.python.org/3/library/tkinter.messagebox.html
        else:
            # Show data sent to broker
            print(f'{self.data_payload} on topic {self.broker_topic} sent to the broker!')
            self.data_packet_info['text'] = f'Published Payload Data: {self.data_payload}'
        finally:
            # Always disconnect from the broker
            self.__brokerdisconnect()

    def __brokerdisconnect(self):
        try:
            # Delay closing the connection to allow for full transaction, then disconnect from broker
            sleep(self.broker_delay)
            self.client.disconnect()
        except:
            messagebox.showerror('Cound not disconnect from the Broker', 'Could not disconnect from the broker.')
        else:
            print(f'#######\n# Subscriber\n#####\nDisconnected subscriber from broker.')            

    def __brokerupdate(self):
    
        try:
            self.broker_address = self.broker_address_txt.get('1.0',END)
            self.broker_address = self.broker_address.rstrip('\n')#[0:-1]
            self.broker_topic = self.broker_topic_txt.get('1.0',END)
            self.broker_topic = self.broker_topic.rstrip('\n')
            self.broker_port_check = int(self.broker_port_txt.get('1.0',END))
             
            if (self.broker_port_check >= 1024) and (self.broker_port_check <= 65535):
                self.broker_port = self.broker_port_check
            else:
                messagebox.showerror('Invalid Broker Data', 'Please enter valid broker data, including broker port range (1024-65535)')
                
            self.data_broker_info['text'] = f'Broker: {self.broker_address} Port: {self.broker_port} - Topic: {self.broker_topic}'
        except:
            messagebox.showerror('Invalid Broker Data', 'Please enter valid broker data, including broker port range (1024-65535)')
            pass
        else:
            messagebox.showinfo('Broker Data Updated', 'Broker information updated successfully.')
        finally:
            print(f'Broker Address: {self.broker_address} Broker Port: {self.broker_port} Broker Topic: {self.broker_topic}')


publish = publisher()
publish.mainloop()